# Pillars of Fortune - Multi-Arena Edition (v2.0.9)

## v2.0.9 - Config-Based Loot System

**Major Update: LootManager now reads from config.yml!**

✅ **No more hardcoded loot** — everything in config.yml
✅ **Full control** — add/remove/modify items instantly
✅ **Weight-based tiers** — junk, common, useful, rare with custom percentages
✅ **Per-item amounts** — set min and max quantity for each item
✅ **Hot reload** — `/pof reload` applies changes instantly (no recompile!)

**Example config structure:**
```yaml
loot:
  junk:
    weight: 50
    items:
      - { material: DIRT,        min-amount: 1, max-amount: 1 }
      - { material: GRAVEL,      min-amount: 1, max-amount: 1 }
      - { material: STICK,       min-amount: 1, max-amount: 1 }

  common:
    weight: 30
    items:
      - { material: STONE,       min-amount: 1, max-amount: 1 }
      - { material: OAK_PLANKS,  min-amount: 1, max-amount: 1 }

  useful:
    weight: 15
    items:
      - { material: IRON_SWORD,  min-amount: 1, max-amount: 1 }
      - { material: BOW,         min-amount: 1, max-amount: 1 }

  rare:
    weight: 5
    items:
      - { material: DIAMOND_SWORD,      min-amount: 1, max-amount: 1 }
      - { material: GOLDEN_APPLE,       min-amount: 1, max-amount: 1 }
```

## How to Customize:

1. **Edit** `config.yml` (in `plugins/PillarsOfFortune/`)
2. **Add/remove items** under each tier
3. **Adjust weights** (higher = more common)
4. **Set min/max amounts** (quantity per drop)
5. **Run** `/pof reload` — changes apply instantly!

## Quick Examples:

### Add an item to rare:
```yaml
rare:
  weight: 5
  items:
    - { material: DIAMOND_SWORD, min-amount: 1, max-amount: 1 }
    - { material: ELYTRA, min-amount: 1, max-amount: 1 }    # NEW
```

### Change weight distribution (more junk, less rare):
```yaml
junk:
  weight: 60    # was 50
common:
  weight: 30
useful:
  weight: 8     # was 15
rare:
  weight: 2     # was 5
```

### Variable quantities (1-5 per drop):
```yaml
junk:
  items:
    - { material: DIRT, min-amount: 1, max-amount: 5 }  # 1-5 dirt per drop
```

## v2.0.8 - Spectator Region Kick

Spectators confined to region boundaries, kicked if they leave or disconnect.

## v2.0.7 - Loot Quantity 1

Each loot item drops as quantity 1.

## v2.0.6 - Spectator Mode

Dead players spectate instead of being eliminated.

## What's in this project

SOURCE CODE. Needs Maven to build.

## Build it

### GitHub Actions:
Push → Auto-rebuild → Download from Artifacts

### IntelliJ IDEA:
File → Open → folder → Maven → Lifecycle → package

### Command line:
```
mvn clean package
```

## Install it

1. Copy `PillarsOfFortune.jar` to `plugins/`
2. Restart server
3. Edit `plugins/PillarsOfFortune/config.yml` as needed
4. Run `/pof reload` to apply changes

## Loot System Features

✅ **4 weighted tiers** — fully customizable
✅ **Per-item control** — min/max amounts
✅ **Easy editing** — just YAML, no Java knowledge needed
✅ **Hot reload** — no server restart needed
✅ **Fallback defaults** — works even if config is missing
✅ **Material validation** — invalid items are skipped with warning

## Valid Material Names

See Bukkit Material enum:
https://hub.spigotmc.org/javadocs/bukkit/org/bukkit/Material.html

Common examples:
- `DIRT`, `STONE`, `OAK_LOG`, `OAK_PLANKS`
- `IRON_SWORD`, `DIAMOND_SWORD`, `BOW`, `ARROW`
- `IRON_HELMET`, `IRON_CHESTPLATE`, `IRON_LEGGINGS`, `IRON_BOOTS`
- `GOLDEN_APPLE`, `ENCHANTED_GOLDEN_APPLE`, `ENDER_PEARL`
- `ELYTRA`, `TRIDENT`, `SHIELD`, `TOTEM_OF_UNDYING`

## Commands

```
/pof join <arena>         - join arena
/pof forcestart <arena>   - start game
/pof stop <arena>         - stop game
/pof reload               - reload config (applies loot changes!)
```

## Complete Feature List (v2.0.9)

✅ Multi-arena system
✅ Direct pillar join + Slow Falling
✅ Movement frozen during waiting
✅ Fall damage enabled
✅ Spectator mode for dead players
✅ Spectator region boundaries
✅ **Config-based loot system** (NEW)
✅ **Hot reload support** (NEW)
✅ WorldGuard region integration
✅ Inventory snapshot & restoration
✅ Permission system
✅ Customizable messages
✅ Per-arena storage

## Changelog

- v2.0.9: Config-based loot system with hot reload
- v2.0.8: Spectator region boundaries and disconnect kick
- v2.0.7: Loot quantity set to 1
- v2.0.6: Spectator mode for dead players
- v2.0.5: Fall damage enabled
- v2.0.4: Direct pillar join, Slow Falling, movement freeze
- v2.0.3: WorldGuard region support
- v2.0.2: Instant elimination fix
- v2.0.1: Inventory loss fix
- v2.0.0: Initial multi-arena release
